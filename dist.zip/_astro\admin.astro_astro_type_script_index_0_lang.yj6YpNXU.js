import{n as a}from"./supabase.C0NSWFp5.js";import"./constants.vYCbAvDF.js";localStorage.getItem("is_admin")!=="true"&&(window.location.href="login.html");const n=document.getElementById("nipTableBody"),i=document.getElementById("emptyState"),s=document.getElementById("addNipForm"),l=document.getElementById("newNip"),d=document.getElementById("logoutAdminBtn");async function o(){if(!(!n||!i))try{const t=await a.getAll();if(t.length===0){n.innerHTML="",i.classList.remove("hidden");return}i.classList.add("hidden"),n.innerHTML=t.map(e=>`
                <tr class="hover:bg-slate-50/50 transition-colors group">
                    <td class="px-8 py-5">
                        <span class="font-extrabold text-slate-700 tracking-tight">${e}</span>
                    </td>
                    <td class="px-8 py-5 text-right">
                        <button onclick="window.removeNip('${e}')" class="p-2.5 text-rose-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-all">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                        </button>
                    </td>
                </tr>
            `).reverse().join("")}catch{alert("Gagal mengambil data dari Cloud")}}window.removeNip=async t=>{if(confirm(`Hapus NIP ${t} dari database Cloud?`))try{await a.remove(t),await o(),alert("NIP Berhasil dihapus dari Cloud!")}catch{alert("Gagal menghapus NIP")}};s?.addEventListener("submit",async t=>{t.preventDefault();const e=l.value.trim();if(e)try{if((await a.getAll()).includes(e)){alert("NIP sudah ada di Cloud!");return}await a.add(e),l.value="",await o(),alert("NIP berhasil disimpan ke Cloud!")}catch{alert('Gagal menyimpan NIP ke Cloud. Pastikan tabel "allowed_nips" sudah dibuat.')}});d?.addEventListener("click",()=>{localStorage.removeItem("is_admin"),window.location.href="login.html"});o();
