import{C as n}from"./storage.BkCL4aWa.js";const i="Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Mobile Safari/537.36",c="https://absensi-kinerja.labuhanbatuselatankab.go.id/absensi",d=()=>window.Capacitor&&window.Capacitor.isNativePlatform();async function l(r,a={}){if(d())try{let e=a.body;a.body instanceof FormData&&(e={},a.body.forEach((s,o)=>{e[o]=s}));const t=await n.request({url:r,method:a.method||"GET",headers:{"User-Agent":i,Referer:c,Accept:"application/json, text/plain, */*",...a.headers,"Content-Type":a.body instanceof FormData?"application/x-www-form-urlencoded":a.headers["Content-Type"]||"application/json"},data:e,connectTimeout:15e3,readTimeout:15e3});if(t.status<200||t.status>=300){const s=`
⚠️ SERVER ERROR (${t.status})
URL: ${r}
Respon: ${typeof t.data=="object"?JSON.stringify(t.data):t.data}
                `;console.error("[Server Error Detail]",s),alert(s)}return{ok:t.status>=200&&t.status<300,status:t.status,json:async()=>t.data,text:async()=>JSON.stringify(t.data)}}catch(e){const t=`
🚫 KONEKSI GAGAL
URL: ${r}
Pesan: ${e.message}
Detail: ${JSON.stringify(e)}
            `;throw alert(t),e}return fetch(r,a)}export{l as s};
